package Homework4;

public class Main {
    public static void main(String[] args) {
        Triangle triangle = new Triangle(6);

    }
}
